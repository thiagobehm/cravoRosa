<footer>
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-md-6 text-center">
				<div class="fb-page" data-href="https://www.facebook.com/kadrithi/" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/kadrithi/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/kadrithi/">Kadrithi</a></blockquote></div>
			</div>
			<div class="col-xs-12 col-md-6">
				<h3 class="title">Informações de Contato</h3>
				<p><i class="fa fa-envelope fa-2x" aria-hidden="true"></i> <a href="mailto:contato@cravorosaeventos.com.br">contato@cravorosaeventos.com.br</a></p>
				<p><i class="fa fa-facebook-official fa-2x" aria-hidden="true"></i> <a href="#">/cravorosacerimonial</a></p>
				<p><i class="fa fa-volume-control-phone fa-2x" aria-hidden="true"></i> <a href="tel:51995444195">(51) 99544.4195</a></p>
			</div>
		</div>
	</div>
</footer>